package lab.dao;

public class CountryNotFoundException extends Exception {

	private static final long serialVersionUID = 1L;
}
