package lab.model;


public class CustomerBrokenException extends RuntimeException {

	private static final long serialVersionUID = 1L;
}
