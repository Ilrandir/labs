package lab.model;

public interface Person {
    public void setName(String name);
    public String getName ();
    public void sayHello(Person person);
}