package lab.model;


public interface Bar {
    Squishee sellSquishee(Customer customer);
}